document.getElementById('registerButton').addEventListener('click', () => {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (name && email && password) {
        alert(`Usuário ${name} cadastrado com sucesso!`);
    } else {
        alert('Por favor, preencha todos os campos.');
    }
});

// Função para inicializar a câmera
async function initializeCamera() {
    const video = document.getElementById('video');
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    video.srcObject = stream;
}

// Função para capturar a foto
document.getElementById('captureButton').addEventListener('click', () => {
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');
    const video = document.getElementById('video');
    const photo = document.getElementById('photo');

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    photo.src = canvas.toDataURL('image/png');
    photo.style.display = 'block';
});

// Inicializa a câmera quando a página carrega
window.addEventListener('load', initializeCamera);
